#include<stdio.h>
main()
{
	float s, a;
	
	printf("Enter the side of Square...");
	scanf("%f",&s);
	
	a=s*s;
	
	printf("Area of Square is...%2f",a);
}
