#include<stdio.h>
main()
{
	int A=4;
	int B=3;
	
	
	printf("The value of Addition of A and B is %d\n",A+B);
	printf("The value of Subtraction of A and B is %d\n",A-B);
	printf("The value of Multiplication of A and B is %d\n",A*B);
	printf("The value of Division of A and B is %d\n",A/B);
	printf("The value of Modulo of A and B is %d\n",A%B);
}
