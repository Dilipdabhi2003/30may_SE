#include<stdio.h>
main()
{
	float s,c;
	
	printf("Enter the Side of Square...");
	scanf ("%f",&s);
	
	
	c=4*s;
	
	printf("Circumference of Square is...%2f",c);
	
}
