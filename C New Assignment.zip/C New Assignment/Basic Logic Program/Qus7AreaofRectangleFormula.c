#include<stdio.h>
main()
{
	float l,w,a;
	
	printf("Enter the Length...");
	scanf("%f",&l);
	
	printf("Enter the Weight...");
	scanf("%f",&w);
	
	a=l*w;
	
	printf("Area of Rectangle is ...%2f",a);	
}
