#include<stdio.h>
main()
{
	float s,a;
	
	printf("Enter the Side for Cube...");
	scanf("%f",&s);
	
	
	a=6*s*s;
	
	printf("Area of Cube...%2f",a);
}
