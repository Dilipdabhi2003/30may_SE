#include<stdio.h>
main()
{
	int ascii;
	
	printf("Enter the ASCII value....");
	scanf("%d",&ascii);
	
	
	printf("Character is...%c\n",ascii);
}
