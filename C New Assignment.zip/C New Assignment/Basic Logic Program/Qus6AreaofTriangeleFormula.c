#include<stdio.h>
main()
{
	float b,h,a;
	
	
	printf("Enter the Base...");
	scanf("%f",&b);
	
	printf("Enter the Hieght...");
	scanf("%f",&h);
	
	
	a= 0.5*b*h;
	
	printf("Area f Triangle is...%2f",&a);
}
