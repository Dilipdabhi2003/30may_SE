#include<stdio.h>
main()
{
	char ch;
	
	printf("Enter the Character...");
	scanf ("%c",ch);
	
	printf("ASCII value is ...%d\n",ch);
}
