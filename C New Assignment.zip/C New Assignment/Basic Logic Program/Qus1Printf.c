// Display this information using Printf

//	Your Name 
//	Your Birth Date
//	Your Age
//	Your Address


#include<stdio.h>
main()
{
	printf("The Name is Aniket Parmar\n");
	printf("The Birthdate is 30/04/2003\n");
	printf("The Age is 20\n");
	printf("The Address is Bhavnagar");
}
