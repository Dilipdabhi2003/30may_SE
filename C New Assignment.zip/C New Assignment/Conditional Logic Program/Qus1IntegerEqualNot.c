#include<stdio.h>
main()
{
	int n1,n2;
	
	printf("Enter the Number 1...");
	scanf("%d",&n1);
	
	printf("Enter the Number 2...");
	scanff("%d",&n2);
	
	if(n1==n2)
	{
		printf("The Entire Integers are Equal...\n");
	}
	else
	{
		printf("The Entire Integers are not Equal...");
	}
}
