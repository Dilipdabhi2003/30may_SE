#include<stdio.h>
main()
{
	int row;
	int col;

	for (row = 1;row <= 6; row++)
	{
		for(col = 1;col <= row;col++)
		{
			printf("*");
		}
		printf("\n");
	}
	for (row = 5;row >= 1;row--)
	{
		for(col = 1;col <= row;col++)
		{
			printf("*");
		}
		printf("\n");
	}
}
