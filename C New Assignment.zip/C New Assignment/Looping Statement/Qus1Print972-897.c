#include <stdio.h>
main() 
{
	for (int i = 972; i >= 897; i--) 
	{
        printf("%d\n", i);
    }
}

